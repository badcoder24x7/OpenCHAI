--[[
--This is an example of cli_filter.lua script for Slurm
--More information about Slurm cli_filter:
-- https://slurm.schedmd.com/cli_filter_plugins.html
--To find names of options, take a look at:
-- src/common/slurm_opt.c
--]]

function _find_in_str(str, arg)
        if str ~= nil then
                local place = string.find(str,arg)
                if place == 1
                then
                        return true
                else
                        return false
                end
        else
                return false
        end
end

function _verbose_wrapper(options, fmt, ...)
        --[[ Implicit definition of arg was removed in Lua 5.2 --]]
        local arg = {...}

        --[[
        --   Logging to client at levels lower than info is only possible for
        --   sbatch and scrontab in case of salloc and srun only info and error
        --   are displayed.
        --   In older versions of Lua - prior to Lua 5.2 you may need to use
        --   unpack as a built-in instead of table.unpack
        --]]

        if options["type"] == "sbatch" or options["type"] == "scrontab" then
                slurm.log_verbose(fmt, table.unpack(arg))
        else
                if options["verbose"] and tonumber(options["verbose"]) >= 1 then
                        slurm.log_info(fmt, table.unpack(arg))
                end
        end
end

function slurm_cli_pre_submit(options, pack_offset)

        --[[
        -- Checks done in cli_filter can be worked around by users switching to different
        -- SLURM_CONF or using their own build of tools where call to cli_filter was removed.
        --
        -- If strict policy enforcement is a requirement than job_submit plugin should be used.
        --]]

        --[[ Dump environment in JSON format --]]
        env_json = slurm.json_env()
        _verbose_wrapper(options, "slurm_cli_pre_submit: Running with following environment variables:%s", env_json);

        --[[ Dump options set when running (slurmctld default behavior is not shown here) --]]
        opt_json = slurm.json_cli_options(options)
        _verbose_wrapper(options, "slurm_cli_pre_submit: Running with following options set:%s", opt_json)

        --[[ Store a variable for potential use in slurm_cli_post_submit --]]
        slurm.cli_store(0,options["type"])

        --[[
        -- Print an advice message to srun user, to avoid --pty for jobs
        -- with time limit higher than 1h
        -- The conditional like options["pty"] == "set" used to work
        -- in versions of Slurm prior to 23.02
        --]]
        if options["type"] == "srun" and options["pty"] ~= nil
        then
            if slurm.time_str2mins(options["time"]) > 60
            then
                slurm.log_info("Running an interactive job, with --pty emulation shouldn't be used with TimeLimit > 1h.")
            end
        end

        if options["type"] == "sbatch" and options["wrap"] ~= nil
        then
                slurm.log_error("--wrap option is forbidden");
                return slurm.ERROR
        end

        local script_location = {}
        script_location[1] = "/opt/supported_scripts"
        script_location[2] = "/opt/supported_scripts2"

        local allowed = false
        for idx,location in ipairs(script_location)
        do
                if _find_in_str(options.argv[1], location)
                then
                        allowed = true
                        break
                end

        end

        if allowed == false
        then
                slurm.log_error("You have to use scripts from one of:")
                for idx, location in ipairs(script_location)
                do
                        slurm.log_error("- %s", location)
                end
                return slurm.ERROR
        end

        return slurm.SUCCESS

end

function slurm_cli_setup_defaults(options, early_pass)

        --[[
        -- Make --hint=nomultithread a default behavior
        -- if user specifies other --hint=XX option then
        -- it will override the setting done here
        --]]
        options['hint'] = 'nomultithread'

        return slurm.SUCCESS
end

function slurm_cli_post_submit(offset, job_id, step_id)
        saved_type = slurm.cli_retrieve(0);
        slurm.log_info("Submitted: %d.%d component: %d using: %s", job_id, step_id, offset, saved_type);
        return slurm.SUCCESS
end
